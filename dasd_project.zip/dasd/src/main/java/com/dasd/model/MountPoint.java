package com.dasd.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mountpoints")
public class MountPoint {
	
	//Primary Key
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long mount_id;
	
	@Column(name = "Mount Point")
	private String mount_point;
	
	@Column(name = "Space Total(In GB)")
	private String space_total;
	
	@Column(name = "Space Used(In GB)")
	private String space_used;
	
	@Column(name = "Space Free(In GB)")
	private String space_free;
	
	@Column(name = "Percentage Full(%)")
	private String percentage_full;
	
	@Column(name = "Status Message")
	private String status_msg;
	
	
		//Default Constructor for performing RestAPI
		public MountPoint() {
			super();
		}


		public MountPoint(long mount_id, String mount_point, String space_total, String space_used, String space_free,
				String percentage_full, String status_msg) {
			super();
			this.mount_id = mount_id;
			this.mount_point = mount_point;
			this.space_total = space_total;
			this.space_used = space_used;
			this.space_free = space_free;
			this.percentage_full = percentage_full;
			this.status_msg = status_msg;
		}


		public long getMount_id() {
			return mount_id;
		}


		public void setMount_id(long mount_id) {
			this.mount_id = mount_id;
		}


		public String getMount_point() {
			return mount_point;
		}


		public void setMount_point(String mount_point) {
			this.mount_point = mount_point;
		}


		public String getSpace_total() {
			return space_total;
		}


		public void setSpace_total(String space_total) {
			this.space_total = space_total;
		}


		public String getSpace_used() {
			return space_used;
		}


		public void setSpace_used(String space_used) {
			this.space_used = space_used;
		}


		public String getSpace_free() {
			return space_free;
		}


		public void setSpace_free(String space_free) {
			this.space_free = space_free;
		}


		public String getPercentage_full() {
			return percentage_full;
		}


		public void setPercentage_full(String percentage_full) {
			this.percentage_full = percentage_full;
		}


		public String getStatus_msg() {
			return status_msg;
		}


		public void setStatus_msg(String status_msg) {
			this.status_msg = status_msg;
		}
		
		



}

	
